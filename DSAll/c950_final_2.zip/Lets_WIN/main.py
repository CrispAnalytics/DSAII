
# Author: Ian Crisp
# Student ID: 010377033
# Course: C950

# Importing necessary modules or libraries
import csv
# Importing necessary modules or libraries
import datetime

class DeliveryUnit:
# Configure the starting settings for the delivery unit
# Defining a function that encapsulates a particular operation or set of operations
    def __init__(self, top_capacity, travel_speed, load_at_present, shipment_list, complete_mileage, actual_location, begin_time):
# Assigning a value to a variable
        self.time = begin_time
# Assigning a value to a variable
        self.capacity = top_capacity
# Assigning a value to a variable
        self.address_locess = actual_location
# Assigning a value to a variable
        self.speed = travel_speed
# Assigning a value to a variable
        self.packages = shipment_list
# Assigning a value to a variable
        self.load = load_at_present
# Assigning a value to a variable
        self.mileage = complete_mileage
# Assigning a value to a variable
        self.depart_time = begin_time

# Defining a function that encapsulates a particular operation or set of operations
    def __repr__(self):
# Returning a value or set of values from a function
        return f"{self.capacity}, {self.speed}, {self.load}, {self.packages}, {self.mileage}, {self.address_locess}, {self.depart_time}"

# Define the Parcel class to represent package details
class Parcel:
# Defining a function that encapsulates a particular operation or set of operations
    def __init__(self, parcel_id, address_loc, city_name, state_name, zip_code, deadline, parcel_weight, status_now):
# Assigning a value to a variable
        self.Deadline_time = deadline
# Assigning a value to a variable
        self.ID = parcel_id
# Assigning a value to a variable
        self.address_locess = address_loc
# Assigning a value to a variable
        self.delivery_status = status_now
# Assigning a value to a variable
        self.city = city_name
# Assigning a value to a variable
        self.state = state_name
# Assigning a value to a variable
        self.weight = parcel_weight
# Assigning a value to a variable
        self.zipcode = zip_code
# Assigning a value to a variable
        self.departure_time = None
# Assigning a value to a variable
        self.delivery_time = None

# Defining a function that encapsulates a particular operation or set of operations
    def __repr__(self):
# Returning a value or set of values from a function
        return f"{self.ID}, {self.address_locess}, {self.city}, {self.state}, {self.zipcode}, {self.Deadline_time}, {self.weight}, {self.delivery_time}, {self.delivery_status}"
# Defining a function that encapsulates a particular operation or set of operations
    def alter_status(self, time_to_check):
# Checking a condition to decide the subsequent flow of the program
        if self.delivery_time < time_to_check:
# Assigning a value to a variable
            self.delivery_status = "Currently delivered"
# General or specific operation
        elif self.departure_time > time_to_check:
# Assigning a value to a variable
            self.delivery_status = "Currently in route"
        else:
# Assigning a value to a variable
            self.delivery_status = "Currently at hub"
# Define a class for Hash Map implementation
class CreateHashMap:
# Defining a function that encapsulates a particular operation or set of operations
    def __init__(self, initial_capacity=20):
# Assigning a value to a variable
        self.table = []
# Beginning a loop to iterate over a sequence of elements
        for _ in range(initial_capacity):
# Adding an element to an existing list
            self.table.append([])
# Defining a function that encapsulates a particular operation or set of operations
    def insert(self, key, value):
# Assigning a value to a variable
        bucket_idx = hash(key) % len(self.table)
# Assigning a value to a variable
        bucket_list = self.table[bucket_idx]
# Beginning a loop to iterate over a sequence of elements
        for kv_pair in bucket_list:
# Checking a condition to decide the subsequent flow of the program
            if kv_pair[0] == key:
# Assigning a value to a variable
                kv_pair[1] = value
# Returning a value or set of values from a function
                return True
# Adding an element to an existing list
        bucket_list.append([key, value])
# Returning a value or set of values from a function
        return True
# Defining a function that encapsulates a particular operation or set of operations
    def lookup(self, key):
# Assigning a value to a variable
        bucket_idx = hash(key) % len(self.table)
# Assigning a value to a variable
        bucket_list = self.table[bucket_idx]
# Beginning a loop to iterate over a sequence of elements
        for kv_pair in bucket_list:
# Checking a condition to decide the subsequent flow of the program
            if kv_pair[0] == key:
# Returning a value or set of values from a function
                return kv_pair[1]
# Returning a value or set of values from a function
        return None
# Defining a function that encapsulates a particular operation or set of operations
    def hash_remove(self, key):
# Assigning a value to a variable
        bucket_idx = hash(key) % len(self.table)
# Assigning a value to a variable
        bucket_list = self.table[bucket_idx]
# Beginning a loop to iterate over a sequence of elements
        for kv_pair in bucket_list:
# Checking a condition to decide the subsequent flow of the program
            if kv_pair[0] == key:
                bucket_list.remove(kv_pair)
# Returning a value or set of values from a function
                return True
# Returning a value or set of values from a function
        return False
# Importing necessary modules or libraries
import csv
# Importing necessary modules or libraries
import datetime
# Load distance data
with open("data/Dst.csv") as dist_file:
# Assigning a value to a variable
    dist_data = csv.reader(dist_file)
# Assigning a value to a variable
    dist_data = list(dist_data)
# Load address data 
with open("data/Addr.csv") as address_loc_file:
# Assigning a value to a variable
    address_locess_data = csv.reader(address_loc_file)
# Assigning a value to a variable
    address_locess_data = list(address_locess_data)
# Load package data
with open("data/pkg.csv") as pkg_file:
# Assigning a value to a variable
    package_data = csv.reader(pkg_file)
# Assigning a value to a variable
    package_data = list(package_data)
# Load parcel data & populate hash table
# Defining a function that encapsulates a particular operation or set of operations
def load_parcel_data(filename, hash_table):
    with open(filename) as pkg_info:
# Assigning a value to a variable
        csv_data = csv.reader(pkg_info)
# Beginning a loop to iterate over a sequence of elements
        for row in csv_data:
# Assigning a value to a variable
            pkg = Parcel(int(row[0]), row[1], row[2], row[3], row[4], row[5], row[6], "At Hub")
            hash_table.insert(int(row[0]), pkg)
# Compute distance between two locations
# Defining a function that encapsulates a particular operation or set of operations
def compute_distance(start, end):
# Assigning a value to a variable
    dist = dist_data[start][end]
# Checking a condition to decide the subsequent flow of the program
    if dist == '':
# Assigning a value to a variable
        dist = dist_data[end][start]
# Returning a value or set of values from a function
    return float(dist)
# Extract address index from address string
# Defining a function that encapsulates a particular operation or set of operations
def get_address_locess_index(address_locess):
# Beginning a loop to iterate over a sequence of elements
    for row in address_locess_data:
# Checking a condition to decide the subsequent flow of the program
        if address_locess in row[2]:
# Returning a value or set of values from a function
            return int(row[0])
# Initialize trucks
# Assigning a value to a variable
truck1 = DeliveryUnit(16, 18, None, [1, 13, 14, 15, 16, 20, 29, 30, 31, 34, 37, 40], 0.0, "4001 South 700 East", datetime.timedelta(hours=8))
# Assigning a value to a variable
truck2 = DeliveryUnit(16, 18, None, [3, 6, 12, 17, 18, 19, 21, 22, 23, 24, 26, 27, 35, 36, 38, 39], 0.0, "4001 South 700 East", datetime.timedelta(hours=10, minutes=20))
# Assigning a value to a variable
truck3 = DeliveryUnit(16, 18, None, [2, 4, 5, 6, 7, 8, 9, 10, 11, 25, 28, 32, 33], 0.0, "4001 South 700 East", datetime.timedelta(hours=9, minutes=5))
# Initialize hash table
# Assigning a value to a variable
parcel_data_table = CreateHashMap()
# Populate hash table with package data
load_parcel_data("data/pkg.csv", parcel_data_table)
# Function to sort packages for delivery using nearest neighbor algorithm
# Defining a function that encapsulates a particular operation or set of operations
def sort_and_deliver(truck):
# Assigning a value to a variable
    pending_delivery = [parcel_data_table.lookup(parcel_id) for parcel_id in truck.packages]
    truck.packages.clear()
# Beginning a loop that will continue as long as a certain condition is met
    while pending_delivery:
# Assigning a value to a variable
        closest_dist = float('inf')
# Assigning a value to a variable
        closest_pkg = None
# Beginning a loop to iterate over a sequence of elements
        for pkg in pending_delivery:
# Assigning a value to a variable
            dist = compute_distance(get_address_locess_index(truck.address_locess), get_address_locess_index(pkg.address_locess))
# Checking a condition to decide the subsequent flow of the program
            if dist <= closest_dist:
# Assigning a value to a variable
                closest_dist = dist
# Assigning a value to a variable
                closest_pkg = pkg
# Adding an element to an existing list
        truck.packages.append(closest_pkg.ID)
        pending_delivery.remove(closest_pkg)
# Assigning a value to a variable
        truck.mileage += closest_dist
# Assigning a value to a variable
        truck.address_locess = closest_pkg.address_locess
# Assigning a value to a variable
        truck.time += datetime.timedelta(hours=closest_dist / 18)
# Assigning a value to a variable
        closest_pkg.delivery_time = truck.time
# Assigning a value to a variable
        closest_pkg.departure_time = truck.depart_time
# Sort and deliver packages for each truck
sort_and_deliver(truck1)
sort_and_deliver(truck2)
# Assigning a value to a variable
truck3.depart_time = min(truck1.time, truck2.time)
sort_and_deliver(truck3)
# EntryPoint class for user interaction
class EntryPoint:
# Outputting information to the console
    print("WGUPS Delivery Service")
# Outputting information to the console
    print("Total distance achieved by total trucks:")
# Outputting information to the console
    print(truck1.mileage + truck2.mileage + truck3.mileage)
# Assigning a value to a variable
    user_input = input("Input 'go' to continue.")
# Checking a condition to decide the subsequent flow of the program
    if user_input == "go":
        try:
# Assigning a value to a variable
            time_input = input("Input a time (HH:MM:SS) to check parcel delivery_status.")
# Assigning a value to a variable
            h, m, s = time_input.split(":")
# Assigning a value to a variable
            time_delta = datetime.timedelta(hours=int(h), minutes=int(m), seconds=int(s))
# Assigning a value to a variable
            view_option = input("Type 'individual' for individual package delivery_status or 'total' for total packages.")
# Checking a condition to decide the subsequent flow of the program
            if view_option == "individual":
                try:
# Assigning a value to a variable
                    parcel_id = input("Enter the ID of the package.")
# Assigning a value to a variable
                    pkg = parcel_data_table.lookup(int(parcel_id))
                    pkg.alter_status(time_delta)
# Outputting information to the console
                    print(str(pkg))
                except ValueError:
# Outputting information to the console
                    print("Improper Input. Closing.")
                    exit()
# Comparing two values for equality
            elif view_option == "total":
                try:
# Beginning a loop to iterate over a sequence of elements
                    for i in range(1, 41):
# Assigning a value to a variable
                        pkg = parcel_data_table.lookup(i)
                        pkg.alter_status(time_delta)
# Outputting information to the console
                        print(str(pkg))
                except ValueError:
# Outputting information to the console
                    print("Improper Input. Closing.")
                    exit()
            else:
                exit()
        except ValueError:
# Outputting information to the console
            print("Improper Input. Closing.")
            exit()
    else:
# Outputting information to the console
        print("Improper Input. Closing.")
        exit()
# Define the Parcel class to represent package details
class Parcel:
    # Set initial attributes for packages
# Defining a function that encapsulates a particular operation or set of operations
    def __init__(self, parcel_id, address_loc, city_name, state_name, zip_code, deadline, parcel_weight, status_now):
# Assigning a value to a variable
        self.Deadline_time = deadline
# Assigning a value to a variable
        self.ID = parcel_id
# Assigning a value to a variable
        self.address_locess = address_loc
# Assigning a value to a variable
        self.delivery_status = status_now
# Assigning a value to a variable
        self.city = city_name
# Assigning a value to a variable
        self.state = state_name
# Assigning a value to a variable
        self.weight = parcel_weight
    
# Assigning a value to a variable
        self.zipcode = zip_code
 
# Assigning a value to a variable
        self.departure_time = None
# Assigning a value to a variable
        self.delivery_time = None

    # Generate string representation of package
# Defining a function that encapsulates a particular operation or set of operations
    def __repr__(self):
# Returning a value or set of values from a function
        return f"{self.ID}, {self.address_locess}, {self.city}, {self.state}, {self.zipcode}, {self.Deadline_time}, {self.weight}, {self.delivery_time}, {self.delivery_status}"

    # Update the package delivery_status based on the given time
# Defining a function that encapsulates a particular operation or set of operations
    def alter_status(self, time_to_check):
# Checking a condition to decide the subsequent flow of the program
        if self.delivery_time < time_to_check:
# Assigning a value to a variable
            self.delivery_status = "Currently delivered"
        elif self.departure_time > time_to_check:
# Assigning a value to a variable
            self.delivery_status = "Currently in route"
        else:
# Assigning a value to a variable
            self.delivery_status = "Currently at the hub"

